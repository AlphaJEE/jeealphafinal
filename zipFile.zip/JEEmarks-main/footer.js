document.addEventListener('DOMContentLoaded', () => {
    const footerPlaceholder = document.querySelector('footer[data-component="footer"]');
    if (footerPlaceholder) {
        fetch('footer.html')
            .then(response => response.text())
            .then(data => {
                footerPlaceholder.innerHTML = data;
            })
            .catch(error => console.error('Error loading footer:', error));
    }
});