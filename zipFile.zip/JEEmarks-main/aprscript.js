/**
 * JEE 2026 Shift Analytics - Performance Alpha Edition (Comprehensive Engine)
 * * This script handles:
 * 1. LIVE DATA SYNCHRONIZATION: Fetching and processing shift data from the Mathongo API.
 * 2. ADVANCED STATISTICAL MODELING: 
 * - Median and Strict Mean calculation.
 * - Population Spread (Standard Deviation and Skewness).
 * - Percentile Predictor via Localized Exponential Decay Interpolation.
 * 3. DYNAMIC UI RENDERING:
 * - Leaderboard ranking with percentile anchors.
 * - Subject-specific difficulty standings.
 * - Synchronized Chart.js visualizations (Comparison, Subject-Stacks, and Distribution).
 * 4. INTERACTIVE CONTROLS: Sorting, visibility toggles, and real-time score prediction.
 */

// --- CONFIGURATION & CONSTANTS ---

import { showToast } from './toast-manager.js';

// Score buckets used for distribution and interpolation
const BUCKET_LABELS = ["0-25", "25-50", "50-75", "75-100", "100-125", "125-150", "150-175", "175-200", "200-225", "225-250", "250-275", "275-300"];

// --- GLOBAL STATE ---

let barChart, distChart, subjectChart;
let processedData = [];
let selectedShiftData = null;
let chartSortMode = 'date'; // 'date' or 'mean'
let currentSubjectIndex = 0; // Rotates through P, C, M for the toughest card
let show150Line = false;
let show99Line = false;
let show98Line = false;


/**
 * Constants
 * Managing the base percentile scores globally
 */
const BASE_99 = 5.3;
const BASE_98 = 9.5;

let current99Target = 5.3; 
let current98Target = 9.5;

// UI Selectors with Guards
const getEl = (id) => document.getElementById(id);

const devTrigger = getEl('dev-trigger');
const devModal = getEl('dev-console-modal');
const closeConsole = getEl('close-console');
const syncStatus = getEl('sync-status');

// Hopium Meter Selectors
const slider = getEl('impactSlider');
const visualThumb = getEl('visualThumb');
const val99Display = getEl('val99');
const val98Display = getEl('val98');
const shiftTag = getEl('shiftTag');
const root = document.documentElement;

// More robust selectors for labels
const lessLabel = document.querySelector('.hopium-strict-label') || document.querySelector('.flex.justify-between span:first-child');
const maxLabel = document.querySelector('.hopium-relaxed-label') || document.querySelector('.flex.justify-between span:last-child');
const resetBtn = getEl('resetBtn');

const subjects = [
    { key: 'p', label: 'Physics Toughest', color: 'text-purple-400', hex: '#a371f7' },
    { key: 'c', label: 'Chemistry Toughest', color: 'text-green-400', hex: '#3fb950' },
    { key: 'm', label: 'Maths Toughest', color: 'text-red-400', hex: '#f85149' }
];

// --- CORE STATISTICAL ENGINE ---
let lastRequestHash = null;
async function runPercentileLogic(isInitialLoad = false) {
    const input = getEl('user-marks-input');
    const display = getEl('predicted-percentile-display');
    const wcContainer = getEl('worst-case-container');
    const predictBtn = getEl('predict-btn'); 
    const wcDisplay = getEl('worst-case-val');
    const devAlert = getEl('deviation-alert');
    
    if (!input || !display) return;
    
    const score = parseFloat(input.value);
    const hopiumVal = slider ? parseFloat(slider.value) : 0;

    const currentRequestData = `${score}-${selectedShiftData?.id}-${hopiumVal}`;
    const currentHash = btoa(currentRequestData);

    if (currentHash === lastRequestHash) {
        input.classList.add('animate-shake');
        if (!isInitialLoad) showToast('Request not sent', 'Duplicate request', 'warning');
        setTimeout(() => input.classList.remove('animate-shake'), 400);
        return; 
    }

    if (isNaN(score) || !selectedShiftData || score < 0 || score > 300) {
        display.innerText = "---";
        if (wcContainer) wcContainer.classList.add('hidden');
        if (devAlert) devAlert.classList.add('hidden');
        return;
    }

    display.classList.add('is-calculating');
    if (predictBtn) {
        predictBtn.innerText = "...";
        predictBtn.disabled = true;
    }
    display.classList.add('animate-pulse');
    display.innerText = "...";

    try {
        const shiftRank = processedData.findIndex(s => s.id === selectedShiftData.id) + 1;

        const response = await fetch('https://digiadvanced.com/predict.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                score: score,
                shiftData: selectedShiftData,
                hopiumVal: hopiumVal,
                shiftRank: shiftRank,
                requestToken: currentHash 
            })
        });

        const result = await response.json();

        if (result.success) {
            display.classList.remove('is-calculating');
            display.classList.add('result-updated');
            lastRequestHash = currentHash;
            display.classList.remove('animate-pulse');
            
            if (score < 290 && parseFloat(result.percentile) >= 99.99) {
                display.innerText = "99.99+";
            } else {
                display.innerText = result.percentile + "%";
            }

            setTimeout(() => {
                display.classList.remove('result-updated');
            }, 800);

            if (result.worstCase && wcContainer && wcDisplay) {
                wcContainer.classList.remove('hidden');
                wcContainer.classList.add('flex', 'flex-col');
                wcDisplay.innerText = result.worstCase + "%";
            } else if (wcContainer) {
                wcContainer.classList.add('hidden');
            }

            if (typeof gtag === 'function') {
                gtag('event', 'predict_score', {
                    'score': score,
                    'shift': selectedShiftData?.id,
                    'hopium_value': hopiumVal,
                    'predicted_percentile': result.percentile,
                    'worst_case': result.worstCase || 'N/A'
                });
            }

            if (hopiumVal !== 0 && devAlert) {
                devAlert.classList.remove('hidden');
                const percentileVal = parseFloat(result.percentile);
                
                if (percentileVal >= 90) {
                    const sign = hopiumVal > 0 ? "+" : "";
                    devAlert.innerText = `${hopiumVal < 0 ? "STRICTER" : "RELAXED"} | ${sign}${hopiumVal.toFixed(2)}% Shift`;
                    devAlert.style.color = hopiumVal > 0 ? "#ff4444" : "#ffcc00"; 
                } else {
                    devAlert.innerText = "No impact of Developer Shift in this zone";
                    devAlert.style.color = "#8b949e";
                }
            } else if (devAlert) {
                devAlert.classList.add('hidden');
            }

        } else {
            throw new Error(result.error || "Prediction Failed");
        }

    } catch (error) {
        if (display) display.classList.remove('is-calculating');
        console.error("API Prediction Error:", error);
        const errorMsg = error.message || "An unexpected error occurred";
        
        showToast('System Error', errorMsg, 'error');
        if (display) {
            display.classList.remove('animate-pulse');
            display.innerText = "ERR";
            display.style.color = "#ff4444";
        }
        
        if (wcContainer) wcContainer.classList.add('hidden');
        if (devAlert) devAlert.classList.add('hidden');
    } finally {
        if (predictBtn) {
            predictBtn.innerText = "Predict";
            predictBtn.disabled = false;
        }
    }
}

function calculateDetailedStats(segments) {
    let totalCount = 0;
    let weightedSum = 0;

    BUCKET_LABELS.forEach((label, index) => {
        const count = Number(segments[label]?.count) || 0;
        const midpoint = (index * 25) + 12.5;
        totalCount += count;
        weightedSum += count * midpoint;
    });

    if (totalCount === 0) return { mean: 0, sd: 0, skew: 0 };
    
    const mean = weightedSum / totalCount;
    let varianceSum = 0;
    let skewnessSum = 0;

    BUCKET_LABELS.forEach((label, index) => {
        const count = Number(segments[label]?.count) || 0;
        const midpoint = (index * 25) + 12.5;
        const deviation = midpoint - mean;
        
        varianceSum += count * Math.pow(deviation, 2);
        skewnessSum += count * Math.pow(deviation, 3);
    });

    const variance = varianceSum / totalCount;
    const sd = Math.sqrt(variance);
    const skew = sd > 0 ? (skewnessSum / totalCount) / Math.pow(sd, 3) : 0;

    return { mean, sd, skew };
}

function calculateScoreForTopPercentage(segments, targetPercentage) {
    let totalCount = 0;
    const counts = BUCKET_LABELS.map(label => {
        const c = Number(segments[label]?.count) || 0;
        totalCount += c;
        return c;
    });

    if (totalCount < 50) return 0;

    const targetRank = totalCount * (targetPercentage / 100);
    let cumulativeRankAbove = 0;
    let targetIdx = -1;

    for (let i = 11; i >= 0; i--) {
        let bucketRankBottom = cumulativeRankAbove + counts[i];
        if (targetRank >= cumulativeRankAbove && targetRank <= bucketRankBottom) {
            targetIdx = i;
            break;
        }
        cumulativeRankAbove = bucketRankBottom;
    }

    if (targetIdx === -1) return 0;

    const scoreHigh = (targetIdx + 1) * 25;
    const rTop = Math.max(0.5, cumulativeRankAbove);
    const rBottom = rTop + Math.max(0.5, counts[targetIdx]);
    
    const k = Math.log(rBottom / rTop) / 25;
    const distanceToTop = Math.log(targetRank / rTop) / k;
    
    return Number(Math.max(scoreHigh - 25, Math.min(scoreHigh, scoreHigh - distanceToTop)).toFixed(1));
}

function calculateMedian(segments) {
    let total = Object.values(segments).reduce((acc, curr) => acc + (Number(curr.count) || 0), 0);
    if (total === 0) return 0;
    
    let midIndex = total / 2;
    let runningSum = 0;

    for (let i = 0; i < 12; i++) {
        let count = Number(segments[BUCKET_LABELS[i]]?.count) || 0;
        if (runningSum + count >= midIndex) {
            let positionInBucket = midIndex - runningSum;
            let percentageThrough = positionInBucket / count;
            return Number(((i * 25) + (percentageThrough * 25)).toFixed(2));
        }
        runningSum += count;
    }
    return 0;
}

// --- DATA PROCESSING & UI INJECTION ---
async function initData() {
    const status = getEl('sync-status');
    const CACHE_KEY = 'jee_alpha_data';
    const CACHE_TIME_KEY = 'jee_alpha_timestamp';
    const CACHE_DURATION = 15 * 60 * 1000;

    const hasScores = (data) => data && data.comparativeScores;

    const loadLocalFallback = async (reason) => {
        try {
            const localRes = await fetch('aprildata.json');
            const localData = await localRes.json();
            
            if (hasScores(localData)) {
                render(localData.comparativeScores);
                if (status) {
                    status.innerText = 'Using Local Backup';
                    status.className = 'text-yellow-500 font-bold italic';
                }
            } else {
                throw new Error("Backup file corrupted");
            }
        } catch (err) {
            if (status) {
                status.innerText = 'Sync Failure';
                status.className = 'text-red-500 font-bold';
            }
            showToast('Sync Error', 'Could not reach server or load backup.', 'error');
        }
    };

    try {
        const cachedData = localStorage.getItem(CACHE_KEY);
        const lastFetch = localStorage.getItem(CACHE_TIME_KEY);
        const now = Date.now();

        if (cachedData && lastFetch && (now - lastFetch < CACHE_DURATION)) {
            const parsedData = JSON.parse(cachedData);
            if (hasScores(parsedData)) {
                render(parsedData.comparativeScores);
                if (status) {
                    status.innerText = 'Cached Feed (Fast Load)';
                    status.className = 'text-blue-400 font-bold italic';
                }
                return;
            }
        }

        const res = await fetch('https://digiadvanced.com/getaprilscores.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });
        
        const json = await res.json();
        
        if (json.success && hasScores(json.data)) {
            localStorage.setItem(CACHE_KEY, JSON.stringify(json.data));
            localStorage.setItem(CACHE_TIME_KEY, now.toString());
            
            render(json.data.comparativeScores);
            if (status) {
                status.innerText = 'Live Feed Active (Secure)';
                status.className = 'text-green-500 font-bold';
            }
        } else {
            await loadLocalFallback('Server data incomplete');
        }

    } catch (e) {
        console.error("Shift Analytics Sync Error:", e);
        await loadLocalFallback('Connection error');
    }
}

function render(scores) {
    let totalStudents = 0;
    let mediansSum = 0;
    let topStudentsCount = 0;
    
    processedData = scores
    .filter(s => s && s._id)
    .map(s => {
        const count = Object.values(s.segments).reduce((acc, curr) => acc + (Number(curr.count) || 0), 0);
        const totalAvg = (s.avgProvisionalPhysicsMarks||0) + (s.avgProvisionalChemistryMarks||0) + (s.avgProvisionalMathematicsMarks||0);
        const eliteCount = ["175-200", "200-225", "225-250", "250-275", "275-300"].reduce((acc, k) => acc + (s.segments[k]?.count || 0), 0);
        const stats = calculateDetailedStats(s.segments);

        return { 
            id: s._id.replace(/\s+/g, ' ').trim(), 
            avg: Number(totalAvg.toFixed(1)), 
            median: calculateMedian(s.segments),
            sd: Number(stats.sd.toFixed(2)),
            skew: Number(stats.skew.toFixed(3)),
            predicted99: calculateScoreForTopPercentage(s.segments, current99Target),
            predicted98: calculateScoreForTopPercentage(s.segments, current98Target),
            p: s.avgProvisionalPhysicsMarks||0, 
            c: s.avgProvisionalChemistryMarks||0, 
            m: s.avgProvisionalMathematicsMarks||0, 
            eliteRatio: Number(((eliteCount/count)*100).toFixed(2)), 
            segments: s.segments, 
            count: count 
        };
    }).filter(s => s.count > 100).sort((a,b) => (a.predicted99 !== b.predicted99) ? (a.predicted99 - b.predicted99) : (a.avg - b.avg));

    processedData.forEach(s => {
        totalStudents += s.count;
        mediansSum += s.median;
        topStudentsCount += (s.eliteRatio * s.count / 100);
    });

    const studentsEl = getEl('total-students-count');
    if (studentsEl) studentsEl.innerText = totalStudents.toLocaleString();
    
    const ratioEl = getEl('global-top-ratio');
    if (ratioEl) ratioEl.innerText = ((topStudentsCount / totalStudents) * 100).toFixed(2) + "%";

    const toughestShift = processedData[0];
    const hardestEl = getEl('hardest-shift');
    if (hardestEl) hardestEl.innerText = toughestShift.id;
    
    const meanDisplay = getEl('hardest-mean-val');
    const medianDisplay = getEl('hardest-median-val');
    
    if (meanDisplay) meanDisplay.innerText = toughestShift.avg;
    if (medianDisplay) medianDisplay.innerText = toughestShift.median;

    updateSubjectToughestCard();
    renderSubjectDistributionRanks();
    renderLeaderboard();
    renderMainComparison();
    renderSubjectAnalysis();
    
    if (processedData.length > 0 && !selectedShiftData) {
        updateCharts(processedData[0]);
        runPercentileLogic(true);
    };
}

function renderLeaderboard() {
    const lb = getEl('leaderboard');
    if (!lb) return;
    lb.innerHTML = '';
    
    processedData.forEach((s, i) => {
        const isActive = selectedShiftData && selectedShiftData.id === s.id;
        let borderColor = 'border-[var(--border-color)]';
        let rankColor = 'text-[var(--text-muted)]';
        let scoreColor = 'text-[var(--text-primary)]';
        let bgStyle = 'bg-[var(--card-bg)]';

        if (isActive) {
            borderColor = 'border-[var(--accent-green)]';
            rankColor = 'text-[var(--accent-green)]';
        } else if (i === 0) {
            borderColor = 'border-red-500/50';
            scoreColor = 'text-[var(--accent-green)]';
        } else {
            rankColor = 'text-[var(--text-secondary)]';
        }

        const card = document.createElement('div');
        card.className = `p-3.5 mb-2.5 flex justify-between items-center cursor-pointer transition-all border ${borderColor} ${bgStyle} rounded-xl hover:brightness-110`;
        
        const rankNum = (i + 1).toString().padStart(2, '0');
        
        card.innerHTML = `
            <div class="flex items-center gap-4">
                <span class="font-bold text-[13px] ${rankColor}">${rankNum}</span>
                <div>
                   <p class="font-bold text-[13.5px] text-[var(--text-primary)] mb-1.5">${s.id}</p>
                   <div class="flex gap-1.5">
                       <span class="text-[7px] px-1.5 py-[3px] rounded-sm bg-red-500/10 text-red-500 font-black uppercase tracking-wider">P99:${Math.round(s.predicted99)}</span>
                       <span class="text-[7px] px-1.5 py-[3px] rounded-sm bg-yellow-500/10 text-yellow-500 font-black uppercase tracking-wider">P98:${Math.round(s.predicted98)}</span>
                   </div>
                </div>
            </div>
            <div class="flex flex-col items-end shrink-0 ml-auto">
                <p class="text-[14px] font-black ${scoreColor} leading-none mb-1.5">${s.avg.toFixed(1)}</p>
                <p class="text-[9px] text-[var(--text-muted)] font-medium uppercase tracking-wide leading-none">Mean</p>
            </div>`;
        
        card.onclick = () => {
            updateCharts(s);
            runPercentileLogic(true);
        };
        lb.appendChild(card);
    });
}

function renderMainComparison() {
    const canvas = getEl('barChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (barChart) barChart.destroy();

    let chartData = [...processedData];
    if (chartSortMode === 'date') {
        chartData.sort((a, b) => getChronologicalVal(a.id) - getChronologicalVal(b.id));
    } else {
        chartData.sort((a, b) => a.avg - b.avg);
    }

    const selectedId = selectedShiftData ? selectedShiftData.id : null;

    const datasets = [
        { 
            label: 'Median', 
            data: chartData.map(d => d.median), 
            backgroundColor: chartData.map(d => d.id === selectedId ? '#00d084' : 'rgba(0, 208, 132, 0.4)'),
            borderColor: chartData.map(d => d.id === selectedId ? '#ffffff' : 'transparent'),
            borderWidth: chartData.map(d => d.id === selectedId ? 1.5 : 0),
            order: 10, 
            barPercentage: 0.6 
        },
        { 
            label: 'Mean', 
            data: chartData.map(d => d.avg), 
            backgroundColor: chartData.map(d => d.id === selectedId ? '#444c56' : 'rgba(48, 54, 61, 0.6)'),
            borderColor: chartData.map(d => d.id === selectedId ? '#ffffff' : 'transparent'),
            borderWidth: chartData.map(d => d.id === selectedId ? 1 : 0),
            order: 11, 
            barPercentage: 0.8 
        }
    ];

    if (show150Line) {
        datasets.push({ 
            label: '150+ Ratio (%)', 
            data: chartData.map(d => d.eliteRatio), 
            borderColor: '#f1e05a', 
            borderWidth: 2, 
            type: 'line', 
            tension: 0.4, 
            pointRadius: chartData.map(d => d.id === selectedId ? 5 : 2),
            pointBackgroundColor: chartData.map(d => d.id === selectedId ? '#ffffff' : '#f1e05a'),
            order: 0, 
            yAxisID: 'y1' 
        });
    }
    if (show99Line) {
        datasets.push({ label: '99%ile Target', data: chartData.map(d => d.predicted99), borderColor: '#f85149', borderWidth: 2, type: 'line', tension: 0.3, order: 1 });
    }
    if (show98Line) {
        datasets.push({ label: '98%ile Target', data: chartData.map(d => d.predicted98), borderColor: '#fb8c00', borderWidth: 2, type: 'line', tension: 0.3, order: 2 });
    }

    barChart = new Chart(ctx, {
        type: 'bar',
        data: { labels: chartData.map(d => d.id), datasets: datasets },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            plugins: { legend: { display: false } }, 
            scales: { 
                y: { grid: { color: 'rgba(48, 54, 61, 0.4)' }, ticks: { color: '#8b949e', font: { size: 10 } } },
                y1: { position: 'right', grid: { display: false }, ticks: { color: '#f1e05a', font: { size: 9 }, callback: (v) => v + '%' }, max: 35 },
                x: { ticks: { color: '#8b949e', font: { size: 9 }, maxRotation: 45, minRotation: 45 } } 
            } 
        }
    });
}

function renderSubjectAnalysis() {
    const canvas = getEl('subjectChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (subjectChart) subjectChart.destroy();
    
    let chartData = [...processedData];
    if (chartSortMode === 'date') {
        chartData.sort((a, b) => getChronologicalVal(a.id) - getChronologicalVal(b.id));
    } else {
        chartData.sort((a, b) => a.avg - b.avg);
    }

    const selectedId = selectedShiftData ? selectedShiftData.id : null;

    subjectChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.map(d => d.id),
            datasets: [
                { label: 'Physics', data: chartData.map(d => d.p), backgroundColor: chartData.map(d => d.id === selectedId ? '#a371f7' : 'rgba(163, 113, 247, 0.4)') },
                { label: 'Chemistry', data: chartData.map(d => d.c), backgroundColor: chartData.map(d => d.id === selectedId ? '#3fb950' : 'rgba(63, 185, 80, 0.4)') },
                { label: 'Maths', data: chartData.map(d => d.m), backgroundColor: chartData.map(d => d.id === selectedId ? '#f85149' : 'rgba(248, 81, 73, 0.4)') }
            ]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            scales: { 
                x: { stacked: true, ticks: { display: false }, grid: { display: false } }, 
                y: { stacked: true, grid: { color: 'rgba(48, 54, 61, 0.2)' }, ticks: { color: '#8b949e', font: { size: 10 } } } 
            }, 
            plugins: { legend: { position: 'top', labels: { color: '#8b949e', boxWidth: 10, font: { size: 10 } } } } 
        }
    });
}

function updateSlider() {
    if (!slider) return;
    const val = parseFloat(slider.value);
    const percent = ((val + 0.5) / 1) * 100;
    
    const paddedPercent = 8 + (percent * 0.84); 
    root.style.setProperty('--thumb-pos-pct', `${paddedPercent}%`);
    
    const intensity = Math.abs(val) / 0.5; 
    const r = Math.floor(59 + (180 * intensity));
    const g = Math.floor(130 * (1 - intensity));
    const b = Math.floor(246 * (1 - intensity));
    const dynamicAccent = `rgb(${r}, ${g}, ${b})`;

    root.style.setProperty('--accent-blue', dynamicAccent);
    root.style.setProperty('--blue-500', dynamicAccent); 
    
    let baseColor, trackGradient;
    if (val < 0) {
        const ratio = Math.abs(val) / 0.5; 
        baseColor = `color-mix(in sRGB, #fcd34d ${ (1-ratio) * 100}%, #ff8a8a)`; 
        trackGradient = `linear-gradient(90deg, #ff8a8a, #fef3c7)`;
        if (lessLabel) lessLabel.style.color = "#ff8a8a";
        if (maxLabel) maxLabel.style.color = "#94a3b8";
        root.style.setProperty('--skull-opacity', ratio);
        root.style.setProperty('--rocket-opacity', 0);
    } else if (val > 0) {
        const ratio = val / 0.5; 
        baseColor = `color-mix(in sRGB, #22c55e ${ratio * 100}%,rgb(83, 213, 51))`;
        trackGradient = `linear-gradient(90deg, #fef3c7, #22c55e)`;
        if (maxLabel) maxLabel.style.color = "#22c55e";
        if (lessLabel) lessLabel.style.color = "#94a3b8";
        root.style.setProperty('--rocket-opacity', ratio);
        root.style.setProperty('--skull-opacity', 0);
    } else {
        baseColor = "#fcd34d";
        trackGradient = "#f1f5f9";
        if (lessLabel) lessLabel.style.color = "#94a3b8";
        if (maxLabel) maxLabel.style.color = "#94a3b8";
    }

    root.style.setProperty('--base-hopium', baseColor);
    root.style.setProperty('--track-gradient', trackGradient);

    current99Target = BASE_99 + val;
    current98Target = BASE_98 + val;
    if (val99Display) val99Display.innerText = `${current99Target.toFixed(2)}%`;
    if (val98Display) val98Display.innerText = `${current98Target.toFixed(2)}%`;

    if (processedData.length > 0) {
        processedData.forEach(s => {
            s.predicted99 = calculateScoreForTopPercentage(s.segments, current99Target);
            s.predicted98 = calculateScoreForTopPercentage(s.segments, current98Target);
        });
        renderLeaderboard();
        renderMainComparison();
        if (selectedShiftData) updateCharts(selectedShiftData);
    }

    if (shiftTag) {
        const sign = val > 0 ? "+" : "";
        shiftTag.innerHTML = `${sign}${val.toFixed(2)}%`;
        shiftTag.style.color = val > 0 ? "#ff4444" : (val < 0 ? "#58a6ff" : "#ffffff");
    }

    const logicNote = getEl('logic-note');
    if (logicNote) {
        if (val < 0) {
            logicNote.innerText = `⚠ Scaling for a tougher crowd`;
            logicNote.style.color = "#ff8a8a";
        } else if (val > 0) {
            logicNote.innerText = `🚀 Scaling for an easier crowd`;
            logicNote.style.color = "#a371f7";
        } else {
            logicNote.innerText = `Standard Calculated Scaling`;
            logicNote.style.color = "#8b949e";
        }
    }
    lastRequestHash = null;
}

function updateCharts(s) {
    selectedShiftData = s;
    const shiftIdEl = getEl('dist-shift-id');
    if (shiftIdEl) shiftIdEl.innerText = s.id;
    
    const sampleEl = getEl('dist-sample-size');
    if (sampleEl) sampleEl.innerText = `${s.count.toLocaleString()} students`;
    
    const topTierEl = getEl('top-tier-stat');
    if (topTierEl) topTierEl.innerText = `175+ Elite: ${s.eliteRatio}%`;
    
    const p99El = getEl('predicted-99-stat');
    if (p99El) p99El.innerText = `P99: ${s.predicted99}`;
    
    const p98El = getEl('predicted-98-stat');
    if (p98El) p98El.innerText = `P98: ${s.predicted98}`;
    
    renderMainComparison();
    renderSubjectAnalysis();
    renderLeaderboard();

    const canvas = getEl('distChart');
    if (!canvas) return;
    const ctxDist = canvas.getContext('2d');
    if (distChart) distChart.destroy();
    
    const plotData = BUCKET_LABELS.map(l => Number(s.segments[l]?.count) || 0);

    distChart = new Chart(ctxDist, {
        type: 'line',
        data: { 
            labels: BUCKET_LABELS, 
            datasets: [{ 
                data: plotData, 
                borderColor: '#00d084', 
                backgroundColor: 'rgba(0, 208, 132, 0.1)', 
                fill: true, 
                tension: 0.4, 
                borderWidth: 3, 
                pointRadius: 4, 
                pointBackgroundColor: BUCKET_LABELS.map(l => parseInt(l.split('-')[0]) >= 150 ? '#f1e05a' : '#00d084')
            }] 
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            plugins: { legend: { display: false } }, 
            scales: { 
                y: { display: true, ticks: { color: '#8b949e', font: { size: 9 } }, grid: { color: 'rgba(48, 54, 61, 0.2)' } }, 
                x: { ticks: { color: '#8b949e', font: { size: 9 }, maxRotation: 45, minRotation: 45 }, grid: { display: false } } 
            } 
        }
    });
}

function updateSubjectToughestCard() {
    if (processedData.length === 0) return;
    const sub = subjects[currentSubjectIndex];
    const toughest = [...processedData].sort((a,b) => a[sub.key] - b[sub.key])[0];
    
    const labelEl = getEl('subject-tough-label');
    const avgEl = getEl('subject-avg-val');
    const cardEl = getEl('subject-toughest-card');
    
    if (labelEl) {
        labelEl.innerText = sub.label;
        labelEl.className = `text-[10px] font-bold uppercase tracking-widest ${sub.color} group-hover:text-green-950/70 transition-colors`;
    }
    
    if (cardEl) cardEl.style.borderColor = `${sub.hex}33`; 
    
    if (avgEl) {
        avgEl.innerText = toughest[sub.key].toFixed(1);
        avgEl.style.color = sub.hex;
    }

    const toughValEl = getEl('subject-tough-val');
    if (toughValEl) toughValEl.innerText = toughest.id;
    
    const totalMedEl = getEl('subject-total-med');
    if (totalMedEl) totalMedEl.innerText = toughest.median;
}

function renderSubjectDistributionRanks() {
    const containers = { p: 'physics-rankings', c: 'chemistry-rankings', m: 'maths-rankings' };
    Object.keys(containers).forEach(key => {
        const list = getEl(containers[key]);
        if (!list) return;
        list.innerHTML = '';
        
        const sorted = [...processedData].sort((a,b) => a[key] - b[key]).slice(0, 3);
        sorted.forEach((s, idx) => {
            const row = document.createElement('div');
            row.className = 'flex justify-between items-center py-1 text-[11px]';
            
            let rankColor = 'text-[var(--text-muted)]';
            if(idx === 0) {
                if(key==='p') rankColor = 'text-[#00d084]';
                if(key==='c') rankColor = 'text-[#3b82f6]';
                if(key==='m') rankColor = 'text-red-500';
            }
            
            row.innerHTML = `
                <span class="text-[var(--text-secondary)] font-bold">${s.id}</span>
                <span class="font-black ${rankColor}">Rank ${idx+1}</span>
            `;
            list.appendChild(row);
        });
    });
}

function getChronologicalVal(id) {
    const match = id.replace(/\s+/g, '').match(/(\d+)[-S]*(\d+)/i);
    if (match) {
        const year = parseInt(match[1]);
        const session = parseInt(match[2]);
        return (year * 10) + session;
    }
    return 0;
}

// Initializers
document.addEventListener('DOMContentLoaded', () => {
    if (slider) {
        slider.addEventListener('input', updateSlider);
        slider.addEventListener('change', () => {
            if (typeof gtag === 'function') {
                gtag('event', 'hopium_adjusted', { 'value': slider.value });
            }
        });
    }
    if (resetBtn) resetBtn.addEventListener('click', () => { if (slider) { slider.value = 0; updateSlider(); } });
    if (devTrigger) devTrigger.addEventListener('click', () => devModal && devModal.classList.remove('hidden'));
    if (closeConsole) closeConsole.addEventListener('click', () => devModal && devModal.classList.add('hidden'));
    showToast('Prediction Update', 'The data has been updated as per the final answer key.', 'success');
    
    const toughCard = getEl('subject-toughest-card');
    if (toughCard) toughCard.onclick = () => { currentSubjectIndex = (currentSubjectIndex + 1) % subjects.length; updateSubjectToughestCard(); };

    const refreshBtn = getEl('refresh-btn');
    if (refreshBtn) refreshBtn.onclick = () => { localStorage.clear(); window.location.href = location.pathname + '?reload=' + new Date().getTime(); };

    const sortMeanBtn = getEl('sort-mean-btn');
    if (sortMeanBtn) sortMeanBtn.onclick = () => { chartSortMode = 'mean'; sortMeanBtn.classList.add('active'); if (getEl('sort-date-btn')) getEl('sort-date-btn').classList.remove('active'); renderMainComparison(); renderSubjectAnalysis(); };

    const sortDateBtn = getEl('sort-date-btn');
    if (sortDateBtn) sortDateBtn.onclick = () => { chartSortMode = 'date'; sortDateBtn.classList.add('active'); if (getEl('sort-mean-btn')) getEl('sort-mean-btn').classList.remove('active'); renderMainComparison(); renderSubjectAnalysis(); };

    const predictBtn = getEl('predict-btn');
    if (predictBtn) predictBtn.onclick = () => runPercentileLogic();

    const marksInput = getEl('user-marks-input');
    if (marksInput) marksInput.onkeypress = (e) => { if (e.key === 'Enter') runPercentileLogic(); };

    const t150 = getEl('toggle-150-line');
    if (t150) t150.onchange = (e) => { show150Line = e.target.checked; renderMainComparison(); };
    const t99 = getEl('toggle-99-line');
    if (t99) t99.onchange = (e) => { show99Line = e.target.checked; renderMainComparison(); };
    const t98 = getEl('toggle-98-line');
    if (t98) t98.onchange = (e) => { show98Line = e.target.checked; renderMainComparison(); };

    const downloadBtn = getEl('downloadBtn');
    if (downloadBtn) downloadBtn.onclick = async () => {
        const urlInput = getEl('urlInput');
        const status = getEl('dl-status');
        const url = urlInput ? urlInput.value.trim() : '';
        if (!url) return;
        try {
            downloadBtn.disabled = true;
            if (status) status.innerText = "Processing...";
            const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
            const response = await fetch(proxyUrl);
            const blob = await response.blob();
            const downloadUrl = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = downloadUrl;
            a.download = 'response.html';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            if (status) status.innerText = "Success!";
        } catch (err) {
            if (status) status.innerText = "Error: Link expired or blocked.";
        } finally {
            downloadBtn.disabled = false;
        }
    };

    updateSlider();
    initData();
    setInterval(initData, 900000); 
    fetchReleaseStatus();
    setInterval(fetchReleaseStatus, 60000);

    // Listen for theme changes to update charts
    document.addEventListener('theme-changed', (e) => {
        updateChartThemes(e.detail.theme);
    });
});

function updateChartThemes(theme) {
    const isLight = theme === 'light';
    const gridColor = isLight ? 'rgba(0,0,0,0.05)' : 'rgba(255,255,255,0.05)';
    const tickColor = isLight ? '#4b5563' : '#8b949e';

    [barChart, distChart, subjectChart].forEach(chart => {
        if (!chart) return;
        
        if (chart.options.scales.x) {
            if (chart.options.scales.x.grid) chart.options.scales.x.grid.color = gridColor;
            if (chart.options.scales.x.ticks) chart.options.scales.x.ticks.color = tickColor;
        }
        if (chart.options.scales.y) {
            if (chart.options.scales.y.grid) chart.options.scales.y.grid.color = gridColor;
            if (chart.options.scales.y.ticks) chart.options.scales.y.ticks.color = tickColor;
        }
        if (chart.options.scales.y1) {
            if (chart.options.scales.y1.ticks) chart.options.scales.y1.ticks.color = isLight ? '#b45309' : '#f1e05a';
        }
        
        if (chart.options.plugins.legend && chart.options.plugins.legend.labels) {
            chart.options.plugins.legend.labels.color = tickColor;
        }
        
        chart.update();
    });
}

// --- STATUS UPDATER FUNCTIONS ---
function updateFinalKeyStatus(status, color = 'text-yellow-400') {
    const element = getEl('final-key-status');
    if (element) {
        element.innerText = status;
        element.className = `text-[15px] font-bold uppercase ${color}`;
    }
}

function updateResultStatus(status, color = 'text-yellow-400') {
    const element = getEl('result-status');
    if (element) {
        element.innerText = status;
        element.className = `text-[15px] font-bold uppercase ${color}`;
    }
}

async function fetchReleaseStatus() {
    const jsonUrl = 'https://digiadvanced.com/resultupdate.php';
    try {
        const response = await fetch(jsonUrl);
        const data = await response.json();
        if (data.finalKeyOut !== undefined) {
            updateFinalKeyStatus(data.finalKeyOut ? 'Released' : 'Not yet released', data.finalKeyOut ? 'text-green-400' : 'text-red-400');
        }
        if (data.resultsOut !== undefined) {
            updateResultStatus(data.resultsOut ? 'Released' : 'Not yet released', data.resultsOut ? 'text-green-400' : 'text-red-400');
        }
    } catch (error) { console.error('Error fetching release status:', error); }
}

// function showToast(title, message, variant = 'info') {
//     const container = getEl('toast-container');
//     if (!container) return;
//     const toast = document.createElement('div');
//     toast.className = `custom-slds-toast toast-${variant} p-4 mb-4 rounded-xl shadow-lg text-white flex items-center gap-4 bg-gray-800 border border-gray-700`;
//     toast.innerHTML = `<div><div class="font-bold">${title}</div><div class="text-sm">${message}</div></div>`;
//     container.prepend(toast);
//     setTimeout(() => toast.remove(), 5000);
// }
