document.addEventListener('DOMContentLoaded', () => {
    const track = document.getElementById('videoTrack');
    const nextVidBtn = document.getElementById('nextVid');
    const prevVidBtn = document.getElementById('prevVid');

    if (!track || !nextVidBtn || !prevVidBtn) {
        console.warn('YouTube video carousel elements not found. Skipping carousel initialization.');
        return;
    }

    nextVidBtn.onclick = () => {
        // Scroll by the width of the container
        track.scrollBy({ left: track.clientWidth, behavior: 'smooth' });
        
        // Reset to start if at the end
        if (track.scrollLeft + track.clientWidth >= track.scrollWidth - 10) {
            track.scrollTo({ left: 0, behavior: 'smooth' });
        }
    };

    prevVidBtn.onclick = () => {
        track.scrollBy({ left: -track.clientWidth, behavior: 'smooth' });
    };

    // Auto-play logic
    let autoTimer = setInterval(() => {
        nextVidBtn.click();
    }, 15000);

    track.onmouseenter = () => clearInterval(autoTimer);
    track.onmouseleave = () => {
        autoTimer = setInterval(() => { nextVidBtn.click(); }, 15000);
    };
});