// sw.js - The Background Worker
self.addEventListener('install', (event) => {
    self.skipWaiting(); // Activate worker immediately
});

self.addEventListener('activate', (event) => {
    event.waitUntil(clients.claim()); // Take control of all open tabs
});

// Listen for messages from your Main Script
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
        const { title, message, icon } = event.data;
        
        self.registration.showNotification(title, {
            body: message,
            icon: icon || './favicon.png',
            badge: './favicon.png',
            tag: 'jee-update', // Prevents duplicate notifications
            renotify: true, // Allow re-notification if the same tag is used
            requireInteraction: true, // Keep the notification until the user interacts
            vibrate: [400,150,700,150,400,150,900]
        });
    }
});