/**
 * JEE 2026 Shift Analytics - Performance Alpha Edition (Comprehensive Engine)
 */

// --- CONFIGURATION & CONSTANTS ---
const BUCKET_LABELS = ["0-25", "25-50", "50-75", "75-100", "100-125", "125-150", "150-175", "175-200", "200-225", "225-250", "250-275", "275-300"];

// --- GLOBAL STATE ---
let barChart, distChart, subjectChart;
let processedData = [];
let selectedShiftData = null;
let chartSortMode = 'date'; 
let currentSubjectIndex = 0; 
let show150Line = true;
let show99Line = true;
let show98Line = true;

const BASE_99 = 6.25;
const BASE_98 = 11.25;

let current99Target = 6.25; 
let current98Target = 11.25;

// UI Selectors
const devTrigger = document.getElementById('dev-trigger');
const devModal = document.getElementById('dev-console-modal');
const closeConsole = document.getElementById('close-console');
const syncStatus = document.getElementById('sync-status');

// Hopium Meter Selectors
const slider = document.getElementById('impactSlider');
const visualThumb = document.getElementById('visualThumb');
const val99Display = document.getElementById('val99');
const val98Display = document.getElementById('val98');
const shiftTag = document.getElementById('shiftTag');
const root = document.documentElement;

// Labels
const lessLabel = document.querySelector('.flex.justify-between.px-8.mt-\\[-8px\\] span:first-child');
const maxLabel = document.querySelector('.flex.justify-between.px-8.mt-\\[-8px\\] span:last-child');
const resetBtn = document.getElementById('resetBtn');

const subjects = [
    { key: 'p', label: 'Physics Toughest', color: 'text-purple-400', hex: '#a371f7' },
    { key: 'c', label: 'Chemistry Toughest', color: 'text-green-400', hex: '#3fb950' },
    { key: 'm', label: 'Maths Toughest', color: 'text-red-400', hex: '#f85149' }
];

// --- CORE STATISTICAL ENGINE ---
let lastRequestHash = null;

async function runPercentileLogic() {
    const input = document.getElementById('user-marks-input');
    const display = document.getElementById('predicted-percentile-display');
    const wcContainer = document.getElementById('worst-case-container');
    const predictBtn = document.getElementById('predict-btn'); 
    const wcDisplay = document.getElementById('worst-case-val');
    const devAlert = document.getElementById('deviation-alert');
    
    const score = parseFloat(input.value);
    const hopiumVal = parseFloat(slider.value); 

    // 1. Generate Fingerprint
    const currentRequestData = `${score}-${selectedShiftData?.id}-${slider.value}`;
    const currentHash = btoa(currentRequestData); 

    // 2. Block Duplicates
    if (currentHash === lastRequestHash) {
        console.log("Duplicate request blocked (Client-side)");
        return; 
    }

    if (isNaN(score) || !selectedShiftData || score < 0 || score > 300) {
        display.innerText = "---";
        wcContainer.classList.add('hidden');
        devAlert.classList.add('hidden');
        return;
    }

    display.classList.add('is-calculating');
    predictBtn.innerText = "..."; 
    predictBtn.disabled = true;    
    display.classList.add('animate-pulse');
    display.innerText = "...";

    try {
        const shiftRank = processedData.findIndex(s => s.id === selectedShiftData.id) + 1;

        // --- CRITICAL UPDATE: POINT TO HOSTINGER BACKEND ---
        const response = await fetch('https://digiadvanced.com/predict.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                score: score,
                shiftData: selectedShiftData,
                hopiumVal: hopiumVal,
                shiftRank: shiftRank,
                requestToken: currentHash 
            })
        });

        const result = await response.json();

        if (result.success) {
            display.classList.remove('is-calculating');
            display.classList.add('result-updated');
            lastRequestHash = currentHash; 
            display.classList.remove('animate-pulse');
            
            if (score < 290 && parseFloat(result.percentile) >= 99.99) {
                display.innerText = "99.99+";
            } else {
                display.innerText = result.percentile + "%";
            }

            setTimeout(() => {
                display.classList.remove('result-updated');
            }, 800);

            if (result.worstCase) {
                wcContainer.classList.remove('hidden');
                wcContainer.classList.add('flex', 'flex-col');
                wcDisplay.innerText = result.worstCase + "%";
            } else {
                wcContainer.classList.add('hidden');
            }

            if (hopiumVal !== 0) {
                devAlert.classList.remove('hidden');
                const percentileVal = parseFloat(result.percentile);
                
                if (percentileVal >= 90) {
                    const sign = hopiumVal > 0 ? "+" : "";
                    devAlert.innerText = `${hopiumVal < 0 ? "STRICTER" : "RELAXED"} | ${sign}${hopiumVal.toFixed(2)}% Shift`;
                    devAlert.style.color = hopiumVal > 0 ? "#ff4444" : "#ffcc00"; 
                } else {
                    devAlert.innerText = "No impact of Developer Shift in this zone";
                    devAlert.style.color = "#8b949e";
                }
            } else {
                devAlert.classList.add('hidden');
            }

        } else {
            throw new Error(result.error || "Prediction Failed");
        }

    } catch (error) {
        display.classList.remove('is-calculating');
        console.error("API Prediction Error:", error);
        display.classList.remove('animate-pulse');
        display.innerText = "ERR";
        display.style.color = "#ff4444";
        wcContainer.classList.add('hidden');
        devAlert.classList.add('hidden');
    } finally {
        predictBtn.innerText = "Predict"; 
        predictBtn.disabled = false;
    }
}

function calculateDetailedStats(segments) {
    let totalCount = 0;
    let weightedSum = 0;

    BUCKET_LABELS.forEach((label, index) => {
        const count = Number(segments[label]?.provisionalCount) || 0;
        const midpoint = (index * 25) + 12.5;
        totalCount += count;
        weightedSum += count * midpoint;
    });

    if (totalCount === 0) return { mean: 0, sd: 0, skew: 0 };
    
    const mean = weightedSum / totalCount;
    let varianceSum = 0;
    let skewnessSum = 0;

    BUCKET_LABELS.forEach((label, index) => {
        const count = Number(segments[label]?.provisionalCount) || 0;
        const midpoint = (index * 25) + 12.5;
        const deviation = midpoint - mean;
        varianceSum += count * Math.pow(deviation, 2);
        skewnessSum += count * Math.pow(deviation, 3);
    });

    const variance = varianceSum / totalCount;
    const sd = Math.sqrt(variance);
    const skew = sd > 0 ? (skewnessSum / totalCount) / Math.pow(sd, 3) : 0;

    return { mean, sd, skew };
}

function calculateScoreForTopPercentage(segments, targetPercentage) {
    let totalCount = 0;
    const counts = BUCKET_LABELS.map(label => {
        const c = Number(segments[label]?.provisionalCount) || 0;
        totalCount += c;
        return c;
    });

    if (totalCount < 50) return 0;

    const targetRank = totalCount * (targetPercentage / 100);
    let cumulativeRankAbove = 0;
    let targetIdx = -1;

    for (let i = 11; i >= 0; i--) {
        let bucketRankBottom = cumulativeRankAbove + counts[i];
        if (targetRank >= cumulativeRankAbove && targetRank <= bucketRankBottom) {
            targetIdx = i;
            break;
        }
        cumulativeRankAbove = bucketRankBottom;
    }

    if (targetIdx === -1) return 0;

    const scoreHigh = (targetIdx + 1) * 25;
    const rTop = Math.max(0.5, cumulativeRankAbove);
    const rBottom = rTop + Math.max(0.5, counts[targetIdx]);
    
    const k = Math.log(rBottom / rTop) / 25;
    const distanceToTop = Math.log(targetRank / rTop) / k;
    
    return Number(Math.max(scoreHigh - 25, Math.min(scoreHigh, scoreHigh - distanceToTop)).toFixed(1));
}

function calculateMedian(segments) {
    let total = Object.values(segments).reduce((acc, curr) => acc + (Number(curr.provisionalCount) || 0), 0);
    if (total === 0) return 0;
    
    let midIndex = total / 2;
    let runningSum = 0;

    for (let i = 0; i < 12; i++) {
        let count = Number(segments[BUCKET_LABELS[i]]?.provisionalCount) || 0;
        if (runningSum + count >= midIndex) {
            let positionInBucket = midIndex - runningSum;
            let percentageThrough = positionInBucket / count;
            return Number(((i * 25) + (percentageThrough * 25)).toFixed(2));
        }
        runningSum += count;
    }
    return 0;
}

// --- DATA PROCESSING & UI INJECTION ---
async function initData() {
    const status = document.getElementById('sync-status');
    const CACHE_KEY = 'jee_alpha_data';
    const CACHE_TIME_KEY = 'jee_alpha_timestamp';
    const CACHE_DURATION = 15 * 60 * 1000; 

    try {
        const cachedData = localStorage.getItem(CACHE_KEY);
        const lastFetch = localStorage.getItem(CACHE_TIME_KEY);
        const now = Date.now();

        if (cachedData && lastFetch && (now - lastFetch < CACHE_DURATION)) {
            const parsedData = JSON.parse(cachedData);
            render(parsedData.comparativeScores);
            status.innerText = 'Cached Feed (Fast Load)';
            status.className = 'text-blue-400 font-bold italic';
            return; 
        }

        // --- CRITICAL UPDATE: POINT TO HOSTINGER DATA PROXY ---
        const res = await fetch('https://digiadvanced.com/get-scores.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });
        
        const json = await res.json();
        
        if (json.success) {
            localStorage.setItem(CACHE_KEY, JSON.stringify(json.data));
            localStorage.setItem(CACHE_TIME_KEY, now.toString());
            render(json.data.comparativeScores);
            status.innerText = 'Live Feed Active (Secure)';
            status.className = 'text-green-500 font-bold';
        } else {
            throw new Error("API Proxy Error");
        }
    } catch (e) {
        console.error("Shift Analytics Sync Error:", e);
        status.innerText = 'Offline / Proxy Error';
        status.className = 'text-red-400 font-bold';
    }
}

function render(scores) {
    let totalStudents = 0;
    let mediansSum = 0;
    let topStudentsCount = 0;
    
    processedData = scores.map(s => {
        const count = Object.values(s.segments).reduce((acc, curr) => acc + (Number(curr.provisionalCount) || 0), 0);
        const totalAvg = (s.avgProvisionalPhysicsMarks||0) + (s.avgProvisionalChemistryMarks||0) + (s.avgProvisionalMathematicsMarks||0);
        const eliteCount = ["150-175", "175-200", "200-225", "225-250", "250-275", "275-300"].reduce((acc, k) => acc + (s.segments[k]?.provisionalCount || 0), 0);
        const stats = calculateDetailedStats(s.segments);

        return { 
            id: s._id.replace(/\s+/g, ' ').trim(), 
            avg: Number(totalAvg.toFixed(1)), 
            median: calculateMedian(s.segments),
            sd: Number(stats.sd.toFixed(2)),
            skew: Number(stats.skew.toFixed(3)),
            predicted99: calculateScoreForTopPercentage(s.segments, current99Target),
            predicted98: calculateScoreForTopPercentage(s.segments, current98Target),
            p: s.avgProvisionalPhysicsMarks||0, 
            c: s.avgProvisionalChemistryMarks||0, 
            m: s.avgProvisionalMathematicsMarks||0, 
            eliteRatio: Number(((eliteCount/count)*100).toFixed(2)), 
            segments: s.segments, 
            count: count 
        };
    }).filter(s => s.count > 100).sort((a,b) => {
        if (a.avg !== b.avg) return a.avg - b.avg;
        return a.predicted99 - b.predicted99;
    });

    processedData.forEach(s => {
        totalStudents += s.count;
        mediansSum += s.median;
        topStudentsCount += (s.eliteRatio * s.count / 100);
    });

    document.getElementById('total-students-count').innerText = totalStudents.toLocaleString();
    document.getElementById('global-median').innerText = (mediansSum / processedData.length).toFixed(1);
    document.getElementById('global-top-ratio').innerText = ((topStudentsCount / totalStudents) * 100).toFixed(2) + "%";

    const toughestShift = processedData[0];
    document.getElementById('hardest-shift').innerText = toughestShift.id;
    document.getElementById('hardest-mean-val').innerText = toughestShift.avg;
    document.getElementById('hardest-median-val').innerText = toughestShift.median;

    updateSubjectToughestCard();
    renderSubjectDistributionRanks();
    renderLeaderboard();
    
    renderMainComparison();
    renderSubjectAnalysis();
    
    if (processedData.length > 0 && !selectedShiftData) {
        updateCharts(processedData[0]);
        runPercentileLogic();
    };
}

function renderLeaderboard() {
    const lb = document.getElementById('leaderboard');
    lb.innerHTML = '';
    
    processedData.forEach((s, i) => {
        const isActive = selectedShiftData && selectedShiftData.id === s.id;
        const card = document.createElement('div');
        card.className = `shift-card p-3 flex justify-between items-center cursor-pointer group ${isActive ? 'active shadow-[0_0_15px_rgba(88,166,255,0.1)]' : ''}`;
        
        card.innerHTML = `
            <div class="flex items-center gap-3">
                <span class="rank-gradient w-7 h-7 rounded-full flex items-center justify-center font-bold text-white text-[10px] shadow-lg shrink-0">${i+1}</span>
                <div>
                   <p class="font-bold text-xs ${isActive ? 'text-blue-400' : 'text-gray-100'}">${s.id}</p>
                   <div class="flex gap-1.5 mt-1.5">
                       <span class="text-[7.5px] px-1.5 py-0.5 rounded bg-red-900/20 border border-red-900/40 text-red-400 font-bold uppercase">P99: ${s.predicted99}</span>
                       <span class="text-[7.5px] px-1.5 py-0.5 rounded bg-orange-900/20 border border-orange-900/40 text-orange-400 font-bold uppercase">P98: ${s.predicted98}</span>
                   </div>
                </div>
            </div>
            <div class="flex flex-col items-end gap-1.5 shrink-0 ml-auto">
                <div class="flex gap-3 mb-0.5">
                    <div class="text-right">
                        <p class="text-[8px] text-gray-500 font-bold uppercase leading-none">Mean</p>
                        <p class="text-xs font-mono font-bold text-blue-400 leading-none mt-1.5">${s.avg}</p>
                    </div>
                    <div class="text-right">
                        <p class="text-[8px] text-gray-500 font-bold uppercase leading-none">Med</p>
                        <p class="text-xs font-mono font-bold text-white leading-none mt-1.5">${s.median}</p>
                    </div>
                </div>
                <span class="text-[7.5px] px-1.5 py-0.5 rounded top-tier-badge font-bold uppercase tracking-tight">Elite: ${s.eliteRatio}%</span>
            </div>`;
        
        card.onclick = () => {
            updateCharts(s);
            runPercentileLogic();
        };
        lb.appendChild(card);
    });
}

function renderMainComparison() {
    const ctx = document.getElementById('barChart').getContext('2d');
    if (barChart) barChart.destroy();

    let chartData = [...processedData];
    if (chartSortMode === 'date') {
        chartData.sort((a, b) => getChronologicalVal(a.id) - getChronologicalVal(b.id));
    } else {
        chartData.sort((a, b) => a.avg - b.avg);
    }

    const selectedId = selectedShiftData ? selectedShiftData.id : null;

    const datasets = [
        { 
            label: 'Median', 
            data: chartData.map(d => d.median), 
            backgroundColor: chartData.map(d => d.id === selectedId ? '#58a6ff' : 'rgba(88, 166, 255, 0.4)'),
            borderColor: chartData.map(d => d.id === selectedId ? '#ffffff' : 'transparent'),
            borderWidth: chartData.map(d => d.id === selectedId ? 1.5 : 0),
            order: 10, 
            barPercentage: 0.6 
        },
        { 
            label: 'Mean', 
            data: chartData.map(d => d.avg), 
            backgroundColor: chartData.map(d => d.id === selectedId ? '#444c56' : 'rgba(48, 54, 61, 0.6)'),
            borderColor: chartData.map(d => d.id === selectedId ? '#ffffff' : 'transparent'),
            borderWidth: chartData.map(d => d.id === selectedId ? 1 : 0),
            order: 11, 
            barPercentage: 0.8 
        }
    ];

    if (show150Line) {
        datasets.push({ 
            label: '150+ Ratio (%)', 
            data: chartData.map(d => d.eliteRatio), 
            borderColor: '#f1e05a', 
            borderWidth: 2, 
            type: 'line', 
            tension: 0.4, 
            pointRadius: chartData.map(d => d.id === selectedId ? 5 : 2),
            pointBackgroundColor: chartData.map(d => d.id === selectedId ? '#ffffff' : '#f1e05a'),
            order: 0, 
            yAxisID: 'y1' 
        });
    }
    if (show99Line) {
        datasets.push({ label: '99%ile Target', data: chartData.map(d => d.predicted99), borderColor: '#f85149', borderWidth: 2, type: 'line', tension: 0.3, order: 1 });
    }
    if (show98Line) {
        datasets.push({ label: '98%ile Target', data: chartData.map(d => d.predicted98), borderColor: '#fb8c00', borderWidth: 2, type: 'line', tension: 0.3, order: 2 });
    }

    barChart = new Chart(ctx, {
        type: 'bar',
        data: { labels: chartData.map(d => d.id), datasets: datasets },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            plugins: { legend: { display: false } }, 
            scales: { 
                y: { grid: { color: 'rgba(48, 54, 61, 0.4)' }, ticks: { color: '#8b949e', font: { size: 10 } } },
                y1: { position: 'right', grid: { display: false }, ticks: { color: '#f1e05a', font: { size: 9 }, callback: (v) => v + '%' }, max: 35 },
                x: { ticks: { color: '#8b949e', font: { size: 9 }, maxRotation: 45, minRotation: 45 } } 
            } 
        }
    });
}

const blobBaseUrl = "https://ndg90xkevgrmoryp.public.blob.vercel-storage.com/proofs/"; 
const totalImages = 14; 
let currentImgIdx = 1;

function updateGallery() {
    const imgElement = document.getElementById('evidence-img');
    const indexDisplay = document.getElementById('img-index');
    const capElement = document.getElementById('gallery-caption');

    if (!imgElement) return;

    const newSrc = `${blobBaseUrl}${currentImgIdx}.jpeg`;
    imgElement.src = newSrc;
    indexDisplay.innerText = `${currentImgIdx} of ${totalImages}`;
    capElement.innerText = `EXHIBIT ${currentImgIdx}: Evidence of Logic Theft & Donation Fraud`;
}

function nextImage() {
    currentImgIdx = (currentImgIdx % totalImages) + 1;
    updateGallery();
}

function prevImage() {
    currentImgIdx = (currentImgIdx === 1) ? totalImages : currentImgIdx - 1;
    updateGallery();
}

function renderSubjectAnalysis() {
    const ctx = document.getElementById('subjectChart').getContext('2d');
    if (subjectChart) subjectChart.destroy();
    
    let chartData = [...processedData];
    if (chartSortMode === 'date') {
        chartData.sort((a, b) => getChronologicalVal(a.id) - getChronologicalVal(b.id));
    } else {
        chartData.sort((a, b) => a.avg - b.avg);
    }

    const selectedId = selectedShiftData ? selectedShiftData.id : null;

    subjectChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.map(d => d.id),
            datasets: [
                { label: 'Physics', data: chartData.map(d => d.p), backgroundColor: chartData.map(d => d.id === selectedId ? '#a371f7' : 'rgba(163, 113, 247, 0.4)') },
                { label: 'Chemistry', data: chartData.map(d => d.c), backgroundColor: chartData.map(d => d.id === selectedId ? '#3fb950' : 'rgba(63, 185, 80, 0.4)') },
                { label: 'Maths', data: chartData.map(d => d.m), backgroundColor: chartData.map(d => d.id === selectedId ? '#f85149' : 'rgba(248, 81, 73, 0.4)') }
            ]
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            scales: { 
                x: { stacked: true, ticks: { display: false }, grid: { display: false } }, 
                y: { stacked: true, grid: { color: 'rgba(48, 54, 61, 0.2)' }, ticks: { color: '#8b949e', font: { size: 10 } } } 
            }, 
            plugins: { legend: { position: 'top', labels: { color: '#8b949e', boxWidth: 10, font: { size: 10 } } } } 
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    updateGallery();
    updateSlider();

    if (window.location.hostname !== 'localhost') {
        const script = document.createElement('script');
        script.src = '/_vercel/insights/script.js';
        script.defer = true;
        document.head.appendChild(script);
    }
});

const openConsole = () => { devModal.classList.remove('hidden'); };

const hideConsole = () => {
    devModal.classList.add('hidden');
    const input = document.getElementById('user-marks-input');
    if (input.value !== "" && !isNaN(parseFloat(input.value))) {
        runPercentileLogic();
    }
};

devTrigger.addEventListener('click', openConsole);
closeConsole.addEventListener('click', hideConsole);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hideConsole(); });
devModal.addEventListener('click', (e) => { if (e.target === devModal) hideConsole(); });

function updateSlider() {
    const val = parseFloat(slider.value);
    const percent = ((val + 0.5) / 1) * 100;
    const paddedPercent = 8 + (percent * 0.84); 
    root.style.setProperty('--thumb-pos-pct', `${paddedPercent}%`);
    
    const intensity = Math.abs(val) / 0.5; 
    const r = Math.floor(59 + (180 * intensity));
    const g = Math.floor(130 * (1 - intensity));
    const b = Math.floor(246 * (1 - intensity));
    const dynamicAccent = `rgb(${r}, ${g}, ${b})`;

    root.style.setProperty('--accent-blue', dynamicAccent);
    root.style.setProperty('--blue-500', dynamicAccent); 
    
    let baseColor, trackGradient;
    if (val < 0) {
        const ratio = Math.abs(val) / 0.5; 
        baseColor = `color-mix(in sRGB, #fcd34d ${ (1-ratio) * 100}%, #ff8a8a)`; 
        trackGradient = `linear-gradient(90deg, #ff8a8a, #fef3c7)`;
        lessLabel.style.color = "#ff8a8a";
        maxLabel.style.color = "#94a3b8";
        root.style.setProperty('--skull-opacity', ratio);
        root.style.setProperty('--rocket-opacity', 0);
    } else if (val > 0) {
        const ratio = val / 0.5; 
        baseColor = `color-mix(in sRGB, #22c55e ${ratio * 100}%,rgb(83, 213, 51))`;
        trackGradient = `linear-gradient(90deg, #fef3c7, #22c55e)`;
        maxLabel.style.color = "#22c55e";
        lessLabel.style.color = "#94a3b8";
        root.style.setProperty('--rocket-opacity', ratio);
        root.style.setProperty('--skull-opacity', 0);
    } else {
        baseColor = "#fcd34d";
        trackGradient = "#f1f5f9";
        lessLabel.style.color = "#94a3b8";
        maxLabel.style.color = "#94a3b8";
    }

    root.style.setProperty('--base-hopium', baseColor);
    root.style.setProperty('--track-gradient', trackGradient);
    root.style.setProperty('--internal-style', `radial-gradient(circle at ${percent}% 50%, #fff6 40px, transparent 60px), ${trackGradient}`);

    current99Target = BASE_99 + val;
    current98Target = BASE_98 + val;
    val99Display.innerText = `${current99Target.toFixed(2)}%`;
    val98Display.innerText = `${current98Target.toFixed(2)}%`;

    if (processedData.length > 0) {
        processedData.forEach(s => {
            s.predicted99 = calculateScoreForTopPercentage(s.segments, current99Target);
            s.predicted98 = calculateScoreForTopPercentage(s.segments, current98Target);
        });
        renderLeaderboard();
        renderMainComparison();
        if (selectedShiftData) updateCharts(selectedShiftData);
    }

    const sign = val > 0 ? "+" : "";
    shiftTag.innerHTML = `${sign}${val.toFixed(2)}%`;
    shiftTag.style.color = val > 0 ? "#ff4444" : (val < 0 ? "#58a6ff" : "#ffffff");

    const logicNote = document.getElementById('logic-note');
    if (val < 0) {
        logicNote.innerText = `⚠ Scaling for a tougher crowd: A score that usually gets 99%ile now requires more marks.`;
        logicNote.style.color = "#ff8a8a";
    } else if (val > 0) {
        logicNote.innerText = `🚀 Scaling for an easier crowd: You'll see higher percentiles for lower scores.`;
        logicNote.style.color = "#a371f7";
    } else {
        logicNote.innerText = `Standard Calculated Scaling`;
        logicNote.style.color = "#8b949e";
    }
    lastRequestHash = null;
}

slider.addEventListener('input', updateSlider);
resetBtn.addEventListener('click', () => { slider.value = 0; updateSlider(); });

function updateCharts(s) {
    selectedShiftData = s;
    document.getElementById('dist-shift-id').innerText = s.id;
    document.getElementById('dist-sample-size').innerText = `${s.count.toLocaleString()} students`;
    document.getElementById('top-tier-stat').innerText = `150+ Elite: ${s.eliteRatio}%`;
    document.getElementById('predicted-99-stat').innerText = `P99: ${s.predicted99}`;
    document.getElementById('predicted-98-stat').innerText = `P98: ${s.predicted98}`;
    
    renderMainComparison();
    renderSubjectAnalysis();
    renderLeaderboard();

    const ctxDist = document.getElementById('distChart').getContext('2d');
    if (distChart) distChart.destroy();
    
    const plotData = BUCKET_LABELS.map(l => Number(s.segments[l]?.provisionalCount) || 0);

    distChart = new Chart(ctxDist, {
        type: 'line',
        data: { 
            labels: BUCKET_LABELS, 
            datasets: [{ 
                data: plotData, 
                borderColor: '#238636', 
                backgroundColor: 'rgba(35, 134, 54, 0.1)', 
                fill: true, 
                tension: 0.4, 
                borderWidth: 3, 
                pointRadius: 4, 
                pointBackgroundColor: BUCKET_LABELS.map(l => parseInt(l.split('-')[0]) >= 150 ? '#f1e05a' : '#238636')
            }] 
        },
        options: { 
            responsive: true, 
            maintainAspectRatio: false, 
            plugins: { legend: { display: false } }, 
            scales: { 
                y: { display: true, ticks: { color: '#8b949e', font: { size: 9 } }, grid: { color: 'rgba(48, 54, 61, 0.2)' } }, 
                x: { ticks: { color: '#8b949e', font: { size: 9 }, maxRotation: 45, minRotation: 45 }, grid: { display: false } } 
            } 
        }
    });
}

function updateSubjectToughestCard() {
    if (processedData.length === 0) return;
    const sub = subjects[currentSubjectIndex];
    const toughest = [...processedData].sort((a,b) => a[sub.key] - b[sub.key])[0];
    
    const labelEl = document.getElementById('subject-tough-label');
    labelEl.innerText = sub.label;
    labelEl.className = `text-[10px] font-bold uppercase tracking-widest ${sub.color}`;
    
    document.getElementById('subject-tough-val').innerText = toughest.id;
    document.getElementById('subject-avg-val').innerText = toughest[sub.key].toFixed(1);
    document.getElementById('subject-total-med').innerText = toughest.median;
}

function renderSubjectDistributionRanks() {
    const containers = { p: 'physics-rankings', c: 'chemistry-rankings', m: 'maths-rankings' };
    Object.keys(containers).forEach(key => {
        const list = document.getElementById(containers[key]);
        const subInfo = subjects.find(s => s.key === key);
        list.innerHTML = '';
        
        const sorted = [...processedData].sort((a,b) => a[key] - b[key]).slice(0, 3);
        sorted.forEach((s, idx) => {
            const row = document.createElement('div');
            row.className = 'flex justify-between items-center bg-gray-900/50 p-2 rounded border border-gray-800 text-[11px]';
            row.innerHTML = `
                <span class="text-gray-500 font-mono">#${idx+1} ${s.id}</span>
                <span class="${subInfo.color} font-bold">${s[key].toFixed(1)} Avg</span>
            `;
            list.appendChild(row);
        });
    });
}

function getChronologicalVal(id) {
    const match = id.replace(/\s+/g, '').match(/(\d+)[-S]*(\d+)/i);
    if (match) {
        const year = parseInt(match[1]);
        const session = parseInt(match[2]);
        return (year * 10) + session;
    }
    return 0;
}

let currentIdx = 0;
const track = document.getElementById('videoTrack');
const total = 2; 

function slideTo(idx) {
    const movePercent = idx * 50; 
    track.style.transform = `translateX(-${movePercent}%)`;
}

document.getElementById('nextVid').onclick = () => { currentIdx = (currentIdx + 1) % total; slideTo(currentIdx); };
document.getElementById('prevVid').onclick = () => { currentIdx = (currentIdx - 1 + total) % total; slideTo(currentIdx); };

let autoTimer = setInterval(() => { currentIdx = (currentIdx + 1) % total; slideTo(currentIdx); }, 15000); 

track.parentElement.onmouseenter = () => clearInterval(autoTimer);
track.parentElement.onmouseleave = () => {
    autoTimer = setInterval(() => { currentIdx = (currentIdx + 1) % total; slideTo(currentIdx); }, 15000);
};

document.getElementById('sort-mean-btn').onclick = () => {
    chartSortMode = 'mean';
    document.getElementById('sort-mean-btn').classList.add('active');
    document.getElementById('sort-date-btn').classList.remove('active');
    renderMainComparison(); 
    renderSubjectAnalysis();
};

document.getElementById('sort-date-btn').onclick = () => {
    chartSortMode = 'date';
    document.getElementById('sort-date-btn').classList.add('active');
    document.getElementById('sort-mean-btn').classList.remove('active');
    renderMainComparison(); 
    renderSubjectAnalysis();
};

document.getElementById('downloadBtn').addEventListener('click', async () => {
    const urlInput = document.getElementById('urlInput');
    const status = document.getElementById('dl-status');
    const btn = document.getElementById('downloadBtn');
    const url = urlInput.value.trim();

    if (!url) return alert("Please paste a URL first!");
    const fileName = url.substring(url.lastIndexOf('/') + 1) || 'response.html';

    try {
        btn.disabled = true;
        btn.innerText = "Processing...";
        status.innerText = "Bypassing CORS and fetching...";
        const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error("Could not fetch file.");
        const blob = await response.blob();
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = fileName; 
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(downloadUrl);
        document.body.removeChild(a);
        status.className = "text-[10px] mt-2 text-green-500 font-bold";
        status.innerText = "Success! File downloaded as: " + fileName;
    } catch (err) {
        status.className = "text-[10px] mt-2 text-red-500 font-bold";
        status.innerText = "Error: Link expired or blocked.";
    } finally {
        btn.disabled = false;
        btn.innerText = "Download HTML";
    }
});

document.getElementById('predict-btn').addEventListener('click', runPercentileLogic);
document.getElementById('user-marks-input').addEventListener('keypress', (e) => { if (e.key === 'Enter') runPercentileLogic(); });
document.getElementById('toggle-150-line').onchange = (e) => { show150Line = e.target.checked; renderMainComparison(); };
document.getElementById('toggle-99-line').onchange = (e) => { show99Line = e.target.checked; renderMainComparison(); };
document.getElementById('toggle-98-line').onchange = (e) => { show98Line = e.target.checked; renderMainComparison(); };
document.getElementById('subject-toughest-card').onclick = () => { currentSubjectIndex = (currentSubjectIndex + 1) % subjects.length; updateSubjectToughestCard(); };
document.getElementById('refresh-btn').onclick = initData;

window.onload = () => { initData(); setInterval(initData, 900000); };