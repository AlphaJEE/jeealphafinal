// advscript.js

// Score buckets for overall distribution. Note: these are 5-mark buckets, not 25-mark.
const OVERALL_BUCKET_LABELS = [
    "-20--15", "-15--10", "-10--5", "-5-0", "0-5", "5-10", "10-15", "15-20", "20-25", "25-30", "30-35", "35-40",
    "40-45", "45-50", "50-55", "55-60", "60-65", "65-70", "70-75", "75-80", "80-85", "85-90", "90-95", "95-100",
    "100-105", "105-110", "110-115", "115-120", "120-125", "125-130", "130-135", "135-140", "140-145", "145-150",
    "150-155", "155-160", "160-165", "165-170", "170-175", "175-180", "180-185", "185-190", "190-195", "195-200",
    "200-205", "205-210", "210-215", "215-220", "220-225", "225-230", "230-235", "235-240", "240-245", "245-250",
    "250-255", "255-260", "260-265", "265-270", "270-275", "275-280", "280-285", "285-290", "290-295", "300-305",
    "305-310", "325-330"
];

const SUBJECT_BUCKET_LABELS = [
    "-10--5", "-5-0", "0-5", "5-10", "10-15", "15-20", "20-25", "25-30", "30-35", "35-40",
    "40-45", "45-50", "50-55", "55-60", "60-65", "65-70", "70-75", "75-80", "80-85", "85-90",
    "90-95", "95-100", "100-105"
];

const CUTOFF_PERCENTAGE = 38; // Top 38% students pass cutoff

// Helper function to parse the start of a score range
const parseRangeStart = (rangeStr) => {
    const parts = rangeStr.split('-');
    // Handle negative ranges like "-20--15"
    if (rangeStr.startsWith('-') && parts.length > 2) {
        return parseInt(parts[0]);
    }
    return parseInt(parts[0]);
};

// Helper function to get sorted keys and data from a segment object
const getSortedKeysAndData = (segmentObj, bucketLabels) => {
    const sortedKeys = bucketLabels.filter(label => segmentObj[label]).sort((a, b) => parseRangeStart(a) - parseRangeStart(b));
    const data = sortedKeys.map(k => segmentObj[k].provisionalCount);
    return { labels: sortedKeys, data: data };
};

// Function to calculate the score for a given top percentage
function calculateScoreForTopPercentage(segments, targetPercentage, bucketLabels) {
    let totalCount = 0;
    const counts = bucketLabels.map(label => {
        const c = Number(segments[label]?.provisionalCount) || 0;
        totalCount += c;
        return c;
    });

    if (totalCount === 0) return 0;

    const targetRank = totalCount * (targetPercentage / 100);
    let cumulativeCountFromTop = 0;
    let cutoffScore = 0;

    // Iterate from highest score bucket to lowest
    for (let i = bucketLabels.length - 1; i >= 0; i--) {
        const label = bucketLabels[i];
        const countInBucket = Number(segments[label]?.provisionalCount) || 0;
        const bucketStart = parseRangeStart(label);
        const bucketEnd = parseInt(label.split('-').pop());
        const bucketSize = bucketEnd - bucketStart;

        cumulativeCountFromTop += countInBucket;

        if (cumulativeCountFromTop >= targetRank) {
            // The cutoff falls within this bucket
            const excessCount = cumulativeCountFromTop - targetRank;
            const proportionInBucket = excessCount / countInBucket;
            cutoffScore = bucketEnd - (proportionInBucket * bucketSize);
            break;
        }
    }
    return Number(cutoffScore.toFixed(1));
}

document.addEventListener('DOMContentLoaded', async () => {
    let rawData;
    try {
        const response = await fetch('advdata.json');
        rawData = await response.json();
    } catch (error) {
        console.error('Error fetching advdata.json:', error);
        // Fallback or error handling if JSON fails to load
        return;
    }

    const d = rawData.data;
    const comp = d.comparativeScores;

    // -------------------------
    // DOM population
    // -------------------------
    document.getElementById('nav-shift-name').innerText = d.examShiftToDisplay;

    // Calculate Total Students (sum of overall segments)
    let totalStudents = 0;
    let peakRange = "";
    let maxCount = 0;

    for (const [key, val] of Object.entries(comp.overall[0].overallSegments)) {
        totalStudents += val.provisionalCount;
        if (val.provisionalCount > maxCount) {
            maxCount = val.provisionalCount;
            peakRange = key;
        }
    }

    document.getElementById('total-students').innerText = totalStudents.toLocaleString();
    document.getElementById('global-mean').innerText = comp.overall[0].avgProvisionalTotalMarks;
    document.getElementById('peak-range').innerText = peakRange + " Marks";

    // Calculate and display cutoff score
    const cutoffScore = calculateScoreForTopPercentage(comp.overall[0].overallSegments, CUTOFF_PERCENTAGE, OVERALL_BUCKET_LABELS);
    document.getElementById('cutoff-score-display').innerText = `${cutoffScore} Marks`;

    // Papers
    document.getElementById('p1-mean').innerText = comp.paper1[0].avgProvisionalTotalMarks;
    document.getElementById('p1-acc').innerText = comp.paper1[0].avgProvisionalAccuracy + '%';
    document.getElementById('p2-mean').innerText = comp.paper2[0].avgProvisionalTotalMarks;
    document.getElementById('p2-acc').innerText = comp.paper2[0].avgProvisionalAccuracy + '%';

    // Subjects Overall Mean
    document.getElementById('phy-mean').innerText = comp.overall[0].avgProvisionalPhysicsMarks;
    document.getElementById('chem-mean').innerText = comp.overall[0].avgProvisionalChemistryMarks;
    document.getElementById('math-mean').innerText = comp.overall[0].avgProvisionalMathematicsMarks;

    // -------------------------
    // Charts Configuration
    // -------------------------
    Chart.defaults.color = '#9ca3af';
    Chart.defaults.font.family = "'Inter', sans-serif";
    const gridColor = 'rgba(255, 255, 255, 0.03)';

    // 1. Overall Distribution Chart
    const overallData = getSortedKeysAndData(comp.overall[0].overallSegments, OVERALL_BUCKET_LABELS);
    const overallCtx = document.getElementById('overallDistChart').getContext('2d');

    new Chart(overallCtx, {
        type: 'bar',
        data: {
            labels: overallData.labels,
            datasets: [{
                label: 'Number of Students',
                data: overallData.data,
                backgroundColor: overallData.labels.map(label => {
                    const bucketStart = parseRangeStart(label);
                    return bucketStart >= cutoffScore ? '#FFD700' : '#00d084'; // Golden color for cutoff
                }),
                borderRadius: 4,
                borderWidth: 0,
                barPercentage: 0.95,
                categoryPercentage: 1.0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#141414',
                    titleColor: '#00d084',
                    bodyColor: '#f8f8f8',
                    borderColor: '#262626',
                    borderWidth: 1,
                    padding: 12,
                    displayColors: false,
                    callbacks: {
                        title: (ctx) => `Score Range: ${ctx[0].label}`,
                        label: (ctx) => `${ctx.raw.toLocaleString()} Students`
                    }
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { maxTicksLimit: 20, font: { size: 10 } }
                },
                y: {
                    grid: { color: gridColor },
                    border: { display: false },
                    beginAtZero: true
                }
            }
        }
    });

    // 2. Paper 1 vs Paper 2 Subject Radar Chart
    const radarCtx = document.getElementById('radarChart').getContext('2d');
    new Chart(radarCtx, {
        type: 'bar',
        data: {
            labels: ['Physics', 'Chemistry', 'Mathematics'],
            datasets: [
                {
                    label: 'Paper 1 Mean',
                    data: [
                        comp.paper1[0].avgProvisionalPhysicsMarks,
                        comp.paper1[0].avgProvisionalChemistryMarks,
                        comp.paper1[0].avgProvisionalMathematicsMarks
                    ],
                    backgroundColor: 'rgba(59, 130, 246, 0.8)', // Blue
                    borderRadius: 6
                },
                {
                    label: 'Paper 2 Mean',
                    data: [
                        comp.paper2[0].avgProvisionalPhysicsMarks,
                        comp.paper2[0].avgProvisionalChemistryMarks,
                        comp.paper2[0].avgProvisionalMathematicsMarks
                    ],
                    backgroundColor: 'rgba(168, 85, 247, 0.8)', // Purple
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: '#f8f8f8', font: { size: 11, weight: 'bold' }, usePointStyle: true }
                },
                tooltip: {
                    backgroundColor: '#141414',
                    titleColor: '#f8f8f8',
                    bodyColor: '#a3a3a3',
                    borderColor: '#262626',
                    borderWidth: 1,
                    padding: 12
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { font: { weight: 'bold', size: 12 }, color: '#f8f8f8' }
                },
                y: {
                    grid: { color: gridColor },
                    border: { display: false },
                    beginAtZero: true,
                    max: 40 // Assuming roughly max average is around 40
                }
            }
        }
    });

    // 3. Subject-wise Distribution Line Chart
    const phyData = getSortedKeysAndData(comp.overall[0].physicsSegments, SUBJECT_BUCKET_LABELS);
    const chemData = getSortedKeysAndData(comp.overall[0].chemistrySegments, SUBJECT_BUCKET_LABELS);
    const mathData = getSortedKeysAndData(comp.overall[0].mathematicsSegments, SUBJECT_BUCKET_LABELS);

    // Since subjects have standard max range (usually -10 to 120), we align on a shared axis.
    const allSet = new Set([...phyData.labels, ...chemData.labels, ...mathData.labels]);
    const sharedLabels = Array.from(allSet).sort((a, b) => parseRangeStart(a) - parseRangeStart(b));

    const getAlignedData = (segmentObj, bucketLabels) => {
        return sharedLabels.map(label => segmentObj[label] ? segmentObj[label].provisionalCount : 0);
    };

    const subjectDistCtx = document.getElementById('subjectDistChart').getContext('2d');
    new Chart(subjectDistCtx, {
        type: 'line',
        data: {
            labels: sharedLabels,
            datasets: [
                {
                    label: 'Physics',
                    data: getAlignedData(comp.overall[0].physicsSegments, SUBJECT_BUCKET_LABELS),
                    borderColor: '#00d084',
                    backgroundColor: 'rgba(0, 208, 132, 0.1)',
                    borderWidth: 2,
                    pointRadius: 0,
                    pointHoverRadius: 6,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Chemistry',
                    data: getAlignedData(comp.overall[0].chemistrySegments, SUBJECT_BUCKET_LABET_LABELS),
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    borderWidth: 2,
                    pointRadius: 0,
                    pointHoverRadius: 6,
                    tension: 0.4,
                    fill: true
                },
                {
                    label: 'Mathematics',
                    data: getAlignedData(comp.overall[0].mathematicsSegments, SUBJECT_BUCKET_LABELS),
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    borderWidth: 2,
                    pointRadius: 0,
                    pointHoverRadius: 6,
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: '#f8f8f8', font: { size: 12, weight: 'bold' }, usePointStyle: true, padding: 20 }
                },
                tooltip: {
                    backgroundColor: '#141414',
                    titleColor: '#f8f8f8',
                    borderColor: '#262626',
                    borderWidth: 1,
                    padding: 12
                }
            },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { maxTicksLimit: 20, font: { size: 10 } }
                },
                y: {
                    grid: { color: gridColor },
                    border: { display: false },
                    beginAtZero: true
                }
            }
        }
    });
});