export function showToast(title, message, variant = 'info', autoClose = true) {
    // Check for container, create it if missing so the module is plug-and-play
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'slds-toast-container';
        document.body.appendChild(container);
    }
    
    const config = {
        'success': { class: 'toast-success', icon: 'success' },
        'error':   { class: 'toast-error',   icon: 'error' },
        'warning': { class: 'toast-warning', icon: 'warning' },
        'warn': { class: 'toast-warning', icon: 'warning' },
        'info':    { class: 'toast-info',    icon: 'info' }
    };

    const setup = config[variant] || config.info;
    const toast = document.createElement('div');
    
    toast.className = `custom-slds-toast ${setup.class}`;
    
    toast.innerHTML = `
        <div style="margin-right: 15px; display: flex; align-items: center; flex-shrink: 0;">
            <svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="currentColor">
                <path d="${getIconPath(setup.icon)}"></path>
            </svg>
        </div>
        <div style="flex: 1;">
            <div style="font-weight: 800; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">${title}</div>
            <div style="font-size: 13px; opacity: 0.95; font-weight: 500;">${message}</div>
        </div>
        <button onclick="this.parentElement.remove()" style="margin-left: 20px; cursor: pointer; opacity: 0.7; font-size: 18px; border: none; background: none; color: white;">✕</button>
    `;

    container.prepend(toast);

    // Only auto-remove if autoClose is true
    if (autoClose) {
        setTimeout(() => {
            if(toast.parentNode) {
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(-20px) translateX(-50%)';
                toast.style.transition = 'all 0.5s ease';
                setTimeout(() => toast.remove(), 500);
            }
        }, 8000);
    }
}

function getIconPath(type) {
    const paths = {
        'success': 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
        'error':   'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z',
        'warning': 'M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z',
        'info':    'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z'
    };
    return paths[type];
}