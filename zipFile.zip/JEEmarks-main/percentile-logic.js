/**
 * JEE Percentile Predictor - Standalone Logic
 * This script handles:
 * 1. Fetching and processing shift data.
 * 2. Percentile prediction based on user score and selected shift.
 * 3. Dynamic UI rendering for the predictor page.
 */

// --- CONFIGURATION & CONSTANTS ---
const BUCKET_LABELS = ["0-25", "25-50", "50-75", "75-100", "100-125", "125-150", "150-175", "175-200", "200-225", "225-250", "250-275", "275-300"];
const BASE_99 = 5; // Aligned with oldpredict.php logic
const BASE_98 = 9.5; // Aligned with oldpredict.php logic

// --- GLOBAL STATE ---
let processedData = [];
let selectedShiftData = null;
let lastRequestHash = null;

// --- STATISTICAL HELPERS ---
/**
 * Calculates the exact median score by finding the 50th percentile student.
 */
function calculateMedian(segments) {
    let total = Object.values(segments).reduce((acc, curr) => acc + (Number(curr.provisionalCount) || 0), 0);
    if (total === 0) return 0;
    
    let midIndex = total / 2;
    let runningSum = 0;

    for (let i = 0; i < 12; i++) {
        let count = Number(segments[BUCKET_LABELS[i]]?.provisionalCount) || 0;
        if (runningSum + count >= midIndex) {
            let positionInBucket = midIndex - runningSum;
            let percentageThrough = positionInBucket / count;
            return Number(((i * 25) + (percentageThrough * 25)).toFixed(2));
        }
        runningSum += count;
    }
    return 0;
}

/**
 * Predicts the score required for a specific top percentage (e.g., 6.5% for 99%ile).
 */
function calculateScoreForTopPercentage(segments, targetPercentage) {
    let totalCount = 0;
    const counts = BUCKET_LABELS.map(label => {
        const c = Number(segments[label]?.provisionalCount) || 0;
        totalCount += c;
        return c;
    });

    if (totalCount < 50) return 0;

    const targetRank = totalCount * (targetPercentage / 100);
    let cumulativeRankAbove = 0;
    let targetIdx = -1;

    for (let i = 11; i >= 0; i--) {
        let bucketRankBottom = cumulativeRankAbove + counts[i];
        if (targetRank >= cumulativeRankAbove && targetRank <= bucketRankBottom) {
            targetIdx = i;
            break;
        }
        cumulativeRankAbove = bucketRankBottom;
    }

    if (targetIdx === -1) return 0;

    const scoreHigh = (targetIdx + 1) * 25;
    const rTop = Math.max(0.5, cumulativeRankAbove);
    const rBottom = rTop + Math.max(0.5, counts[targetIdx]);
    
    const k = Math.log(rBottom / rTop) / 25;
    const distanceToTop = Math.log(targetRank / rTop) / k;
    
    return Number(Math.max(scoreHigh - 25, Math.min(scoreHigh, scoreHigh - distanceToTop)).toFixed(1));
}

// --- CORE PREDICTION ENGINE ---
async function runPercentileLogic() {
    const input = document.getElementById('user-marks-input');
    const display = document.getElementById('predicted-percentile-display');
    const wcContainer = document.getElementById('worst-case-container');
    const predictBtn = document.getElementById('predict-btn');
    const wcDisplay = document.getElementById('worst-case-val');
    const p99Display = document.getElementById('p99-score-display');
    const p98Display = document.getElementById('p98-score-display');
    const p90Display = document.getElementById('p90-score-display');
    
    const score = parseFloat(input.value);
    const impactSlider = document.getElementById('impactSlider');
    const hopiumVal = impactSlider ? parseFloat(impactSlider.value) : 0;

    // 1. Generate a "Fingerprint" of this specific request
    // The new request token must include hopiumVal and base values to match the new backend.
    const currentRequestData = `${score}-${selectedShiftData?.id}-${hopiumVal}-${BASE_99}-${BASE_98}`;
    const currentHash = btoa(currentRequestData); // Simple Base64 "hash"

    // 2. Block if it's a duplicate of the last successful call
    if (currentHash === lastRequestHash) {
        console.log("Duplicate request blocked (Client-side)");
        if (input.classList) { // Check if classList exists
            input.classList.add('animate-shake');
            setTimeout(() => input.classList.remove('animate-shake'), 400);
        }
        showToast('Request not sent', 'Duplicate request', 'warning');
        return; 
    }

    // 3. Basic Validation & Reset
    if (isNaN(score) || !selectedShiftData || score < 0 || score > 300) {
        display.innerText = "---";
        wcContainer.classList.add('hidden');
        p99Display.innerText = '--';
        p98Display.innerText = '--';
        p90Display.innerText = '--';
        showToast('Request not sent', 'Invalid input or no shift selected', 'warning');
        return;
    }

    // 4. Visual Feedback (Loading state)
    display.classList.add('is-calculating');
    predictBtn.innerText = "...";
    predictBtn.disabled = true;
    display.classList.add('animate-pulse');
    display.innerText = "...";

    try {
        // 5. Determine Shift Rank for the Worst Case logic
        const shiftRank = processedData.findIndex(s => s.id === selectedShiftData.id) + 1;

        // 6. API Request to the NEW secure Predictor Proxy
        const response = await fetch('https://digiadvanced.com/directpredict.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                score: score,
                shiftId: selectedShiftData.id, // Send ONLY the ID
                hopiumVal: hopiumVal,
                shiftRank: shiftRank,
                base99: BASE_99, // Send optional base values
                base98: BASE_98,
                requestToken: currentHash 
            })
        });

        const result = await response.json();

        if (result.success) {
            display.classList.remove('is-calculating');
            display.classList.add('result-updated');
            lastRequestHash = currentHash; // Update hash only on success
            display.classList.remove('animate-pulse');
            
            if (score < 290 && parseFloat(result.percentile) >= 99.99) {
                display.innerText = "99.99+";
            } else {
                display.innerText = result.percentile + "%";
            }

            setTimeout(() => {
                display.classList.remove('result-updated');
            }, 800);

            if (typeof gtag === 'function') {
                gtag('event', 'predict_score', {
                    'score': score,
                    'shift': selectedShiftData?.id,
                    'hopium_value': hopiumVal,
                    'predicted_percentile': result.percentile,
                    'worst_case': result.worstCase || 'N/A'
                });
            }

            if (result.worstCase) {
                wcContainer.classList.remove('hidden');
                wcContainer.classList.add('flex', 'flex-col');
                wcDisplay.innerText = result.worstCase + "%";
            } else {
                wcContainer.classList.add('hidden');
            }

            if (result.p99_score) {
                p99Display.innerText = result.p99_score;
                p98Display.innerText = result.p98_score;
                p90Display.innerText = result.p90_score;
            }

        } else {
            throw new Error(result.error || "Prediction Failed");
        }

    } catch (error) {
        display.classList.remove('is-calculating');
        console.error("API Prediction Error:", error);
        const errorMsg = error.message || "An unexpected error occurred";
        showToast('System Error', errorMsg, 'error');
        display.classList.remove('animate-pulse');
        display.innerText = "ERR";
        display.style.color = "#ff4444";
        wcContainer.classList.add('hidden');
        p99Display.innerText = 'ERR';
        p98Display.innerText = 'ERR';
        p90Display.innerText = 'ERR';
    } finally {
        predictBtn.innerText = "Predict";
        predictBtn.disabled = false;
    }
}

// --- DATA PROCESSING ---
async function initData() {
    const status = document.getElementById('sync-status');
    const CACHE_KEY = 'jee_alpha_data_percentile_page'; // Use a different cache key
    const CACHE_TIME_KEY = 'jee_alpha_timestamp_percentile_page';
    const CACHE_DURATION = 15 * 60 * 1000;

    const hasScores = (data) => data && data.comparativeScores;

    const loadLocalFallback = async () => {
        try {
            const localRes = await fetch('raw_jee_data.json');
            const localData = await localRes.json();
            if (hasScores(localData)) {
                render(localData.comparativeScores);
                status.innerText = 'Using Local Backup';
                status.className = 'text-yellow-500 font-bold italic';
                showToast('Data Note', 'Live data unavailable. Switched to local backup.', 'info');
            } else {
                throw new Error("Backup file corrupted");
            }
        } catch (err) {
            status.innerText = 'Sync Failure';
            status.className = 'text-red-500 font-bold';
            showToast('Sync Error', 'Could not reach server or load backup.', 'error');
        }
    };

    try {
        const cachedData = localStorage.getItem(CACHE_KEY);
        const lastFetch = localStorage.getItem(CACHE_TIME_KEY);
        const now = Date.now();

        if (cachedData && lastFetch && (now - lastFetch < CACHE_DURATION)) {
            const parsedData = JSON.parse(cachedData);
            if (hasScores(parsedData)) {
                render(parsedData.comparativeScores);
                status.innerText = 'Cached Feed (Fast Load)';
                status.className = 'text-blue-400 font-bold italic';
                return;
            }
        }

        const res = await fetch('https://digiadvanced.com/get-scores.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });
        
        const json = await res.json();
        
        if (json.success && hasScores(json.data)) {
            localStorage.setItem(CACHE_KEY, JSON.stringify(json.data));
            localStorage.setItem(CACHE_TIME_KEY, now.toString());
            render(json.data.comparativeScores);
            status.innerText = 'Live Feed Active (Secure)';
            status.className = 'text-green-500 font-bold';
        } else {
            await loadLocalFallback();
        }

    } catch (e) {
        console.error("Shift Analytics Sync Error:", e);
        await loadLocalFallback();
    }
}

function render(scores) {
    processedData = scores.map(s => {
        const count = Object.values(s.segments).reduce((acc, curr) => acc + (Number(curr.provisionalCount) || 0), 0);
        const totalAvg = (s.avgProvisionalPhysicsMarks||0) + (s.avgProvisionalChemistryMarks||0) + (s.avgProvisionalMathematicsMarks||0);
        
        return { 
            id: s._id.replace(/[\s.-]+/g, ''), 
            avg: Number(totalAvg.toFixed(1)), 
            median: calculateMedian(s.segments),
            predicted99: calculateScoreForTopPercentage(s.segments, BASE_99),
            predicted98: calculateScoreForTopPercentage(s.segments, BASE_98),
            segments: s.segments, 
            count: count 
        };
    }).filter(s => s.count > 100).sort((a,b) => a.avg - b.avg);

    // Populate the shift selector
    const shiftSelector = document.getElementById('shift-selector');
    shiftSelector.innerHTML = '<option value="">-- Select a Shift --</option>'; // Clear and add placeholder
    processedData.forEach((s, i) => {
        const option = document.createElement('option');
        option.value = i; // Use index as value
        option.innerText = `${s.id} (Mean: ${s.avg}, P99: ${s.predicted99})`;
        shiftSelector.appendChild(option);
    });

    // Set the first shift as selected by default
    if (processedData.length > 0) {
        shiftSelector.value = "0";
        selectedShiftData = processedData[0];
    }
}

// --- TOAST NOTIFICATION SYSTEM ---
function showToast(title, message, variant = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const config = {
        'success': { class: 'toast-success', icon: 'success' },
        'error':   { class: 'toast-error',   icon: 'error' },
        'warning': { class: 'toast-warning', icon: 'warning' },
        'info':    { class: 'toast-info',    icon: 'info' }
    };

    const setup = config[variant] || config.info;
    const toast = document.createElement('div');
    
    toast.className = `custom-slds-toast ${setup.class}`;
    
    toast.innerHTML = `
        <div style="margin-right: 15px; display: flex; align-items: center; flex-shrink: 0;">
            <svg style="width: 24px; height: 24px;" viewBox="0 0 24 24" fill="currentColor">
                <path d="${getIconPath(setup.icon)}"></path>
            </svg>
        </div>
        <div style="flex: 1;">
            <div style="font-weight: 800; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">${title}</div>
            <div style="font-size: 13px; opacity: 0.95; font-weight: 500;">${message}</div>
        </div>
        <button onclick="this.parentElement.remove()" style="margin-left: 20px; cursor: pointer; opacity: 0.7; font-size: 18px; border: none; background: none; color: white;">✕</button>
    `;

    container.prepend(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-20px)';
        toast.style.transition = 'all 0.5s ease';
        setTimeout(() => toast.remove(), 500);
    }, 8000);
}

function getIconPath(type) {
    const paths = {
        'success': 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
        'error':   'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z',
        'warning': 'M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z',
        'info':    'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z'
    };
    return paths[type];
}

// --- INITIALIZATION & EVENT LISTENERS ---
document.addEventListener('DOMContentLoaded', () => {
    
    showToast('Prediction Update', 'The data has been updated as per the final answer key.', 'success');
    initData();

    document.getElementById('predict-btn').addEventListener('click', runPercentileLogic);

    document.getElementById('user-marks-input').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            runPercentileLogic();
        }
    });

    document.getElementById('shift-selector').addEventListener('change', (e) => {
        const selectedIndex = e.target.value;
        if (selectedIndex !== "" && processedData[selectedIndex]) {
            selectedShiftData = processedData[selectedIndex];
            lastRequestHash = null; // Allow re-prediction for new shift
            // Automatically predict when shift changes if marks are entered
            if (document.getElementById('user-marks-input').value) {
                runPercentileLogic();
            }
        } else {
            selectedShiftData = null;
        }
    });

    const impactSlider = document.getElementById('impactSlider');
    const visualThumb = document.getElementById('visualThumb');
    const root = document.documentElement;

    if (impactSlider) {
        impactSlider.addEventListener('input', () => {
            const val = parseFloat(impactSlider.value);
            const percent = ((val + 0.5) / 1) * 100;
            const paddedPercent = 8 + (percent * 0.84); 
            root.style.setProperty('--thumb-pos-pct', `${paddedPercent}%`);
            
            const intensity = Math.abs(val) / 0.5;
            root.style.setProperty('--skull-opacity', val < 0 ? intensity : 0);
            root.style.setProperty('--rocket-opacity', val > 0 ? intensity : 0);
            
            const r = Math.floor(59 + (180 * intensity));
            const g = Math.floor(130 * (1 - intensity));
            const b = Math.floor(246 * (1 - intensity));
            if (visualThumb) visualThumb.style.borderColor = val === 0 ? '#3b82f6' : `rgb(${r},${g},${b})`;
            
            // Allow re-prediction when slider changes
            lastRequestHash = null;
            if (document.getElementById('user-marks-input').value) {
                runPercentileLogic();
            }
        });
    }
});