import { showToast } from './toast-manager.js';

const PaymentSystem = {
    RAZORPAY_KEY_ID: "rzp_live_SGrnlHHuunx030", 
    currentAmount: 0,
    currentTier: "",

    openPayment(amount, tierName) {
        this.currentAmount = amount;
        this.currentTier = tierName;
        const modal = document.getElementById('payment-modal');
        const amtSpan = document.getElementById('modal-pay-amount');
        const tierSpan = document.getElementById('modal-tier-name');
        
        if(amtSpan) amtSpan.innerText = `₹${amount}`;
        if(tierSpan) tierSpan.innerText = tierName;
        if(modal) modal.style.display = 'flex';

        if (typeof gtag === 'function') {
            gtag('event', 'open_payment', {
                'amount': amount,
                'tier_name': tierName
            });
        }
    },

    initiateRazorpay() {
        const name = document.getElementById('user-name').value.trim();
        const email = document.getElementById('user-email').value.trim();
        const handle = document.getElementById('user-handle').value.trim() || "N/A";
        
        if (!name || !email) {
            showToast('Missing Info', 'Please provide Name and Email.', 'warning');
            return;
        }

        try {
            showToast('Secure Link', 'Opening secure payment gateway...', 'info');
        } catch (e) {
            console.error("Toast failed:", e);
        }

        if (typeof gtag === 'function') {
            gtag('event', 'initiate_payment', {
                'amount': this.currentAmount,
                'tier_name': this.currentTier
            });
        }

        const options = {
            "key": this.RAZORPAY_KEY_ID,
            "amount": this.currentAmount * 100, 
            "currency": "INR",
            "name": "AlphaJEE Support",
            "description": `${this.currentTier} Tier`,
            "handler": async (response) => {
                showToast('Processing', 'Verifying your support...', 'info');
                // Use await here to ensure the verification finishes
                await this.verifyOnServer(
                    response.razorpay_payment_id, 
                    this.currentAmount, 
                    this.currentTier, 
                    { name, email, handle }
                );
            },
            "prefill": { "name": name, "email": email },
            "notes": { "social_handle": handle, "tier": this.currentTier },
            "theme": { "color": "#58a6ff" },
            "modal": {
                "ondismiss": () => {
                    showToast('Cancelled', 'Payment window closed.', 'info');
                }
            }
        };

        if (typeof Razorpay !== 'undefined') {
            const rzp1 = new Razorpay(options);
            rzp1.open();
        } else {
            showToast('Error', 'Razorpay SDK not found!', 'error');
        }
    },

    async verifyOnServer(paymentId, amount, tier, userData) {
        try {
            const response = await fetch('https://digiadvanced.com/verify-payment.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    payment_id: paymentId, 
                    amount: amount, 
                    tier: tier, 
                    userData: userData 
                })
            });

            const result = await response.json();

            // Always close the input modal once we have a response
            this.closeModal();

            if (result.success) {
                // Trigger the Legend Moda
                showToast('Success!', `Thank you ${userData.name}! Your support is verified.`, 'success'); 

                this.showThankYou(userData.name, tier);
            } else if (result.error && result.error.includes("manually")) {
                // Soft warning for 'authorized' status
                showToast('Payment Pending', result.error, 'warning');
            } else {
                showToast('Action Required', result.error || 'Verification failed.', 'error');
            }
        } catch (e) {
            console.error("Server Error:", e);
            showToast('Connection Issue', 'Could not reach server. Data might not be saved.', 'error');
            this.closeModal();
        }
    },

    showThankYou(name, tier) {
        const tyModal = document.getElementById('thank-you-modal');
        const msg = document.getElementById('thank-you-message');
        
        if (tyModal && msg) {
            msg.innerHTML = `Massive Respect, ${name}! <br> <span style="font-size: 0.9rem; font-weight: 400; color: var(--accent-blue);">The ${tier} Tier unlocked!</span>`;
            tyModal.style.display = 'flex';
            console.log(`%c LEGEND SPOTTED: ${name} supported at ${tier} level! `, 'background: #f1e05a; color: #000; font-weight: bold;');
        }
    },

    closeModal() {
        const modal = document.getElementById('payment-modal');
        if(modal) modal.style.display = 'none';
    },

    closeThankYou() {
        const tyModal = document.getElementById('thank-you-modal');
        if(tyModal) tyModal.style.display = 'none';
    }
};

// Global Bridges
window.PaymentSystem = PaymentSystem;
window.closeModal = () => PaymentSystem.closeModal();
window.closeThankYouModal = () => PaymentSystem.closeThankYou();

document.addEventListener('DOMContentLoaded', () => {
    const payBtn = document.getElementById('btn-trigger-razorpay');
    if(payBtn) payBtn.onclick = () => PaymentSystem.initiateRazorpay();
});